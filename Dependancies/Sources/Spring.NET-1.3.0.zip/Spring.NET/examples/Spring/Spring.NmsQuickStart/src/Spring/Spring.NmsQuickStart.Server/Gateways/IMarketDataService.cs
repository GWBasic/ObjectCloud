namespace Spring.NmsQuickStart.Server.Gateways
{
    public interface IMarketDataService
    {
        void SendMarketData();
    }
}