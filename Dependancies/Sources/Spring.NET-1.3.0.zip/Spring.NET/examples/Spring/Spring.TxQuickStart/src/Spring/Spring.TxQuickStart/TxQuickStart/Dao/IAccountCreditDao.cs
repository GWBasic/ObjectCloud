

namespace Spring.TxQuickStart.Dao
{
    public interface IAccountCreditDao
    {
        void CreateCredit(float creditAmount);
    }
}
