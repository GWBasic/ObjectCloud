using Spring.TxQuickStart.Dao;

namespace Spring.TxQuickStart.Services
{
    public class StubAccountDebitDao : IAccountDebitDao
    {
        public void DebitAccount(float debitAmount)
        {
            
        }
    }
}