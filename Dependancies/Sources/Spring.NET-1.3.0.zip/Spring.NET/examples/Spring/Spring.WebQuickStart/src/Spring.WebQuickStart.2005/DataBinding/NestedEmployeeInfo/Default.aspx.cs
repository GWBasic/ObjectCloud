/// <summary>
/// Notice that your web page has to extend Spring.Web.UI.Page class
/// in order to enable data binding and many other features.
/// </summary>
public partial class DataBinding_RobustEmployeeInfo_Default : Spring.Web.UI.Page
{
    private EmployeeInfoEditor employeeInfoEditor;
}

