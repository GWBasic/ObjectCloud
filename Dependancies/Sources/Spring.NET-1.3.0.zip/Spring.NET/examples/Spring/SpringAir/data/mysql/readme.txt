This directory contains scripts for creating and populating the SpringAir database on MySQL.

MySQL - http://www.mysql.com/

Note: the MySQL version that I (the author) used to write and tests these scripts against was 5.0.16 (Win32). It has not been tested against any other version (or indeed on any other operating system).
