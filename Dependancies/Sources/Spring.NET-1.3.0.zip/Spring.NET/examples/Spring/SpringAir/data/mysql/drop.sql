drop table reserved_seat;
drop table leg_seat;

drop table leg;
drop table reservation;
drop table flight;

drop table airport;
drop table aircraft_cabin_seat;
drop table aircraft;

drop table cabin_class;
drop table passenger;
