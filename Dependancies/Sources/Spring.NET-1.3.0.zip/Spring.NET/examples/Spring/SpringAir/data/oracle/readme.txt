This directory contains scripts for creating and populating the SpringAir database on Oracle.

Note: the Oracle version that I (the author) used to write and tests these scripts against was Oracle9i Enterprise Edition Release 9.2.0.1.0 (Win32). It has not been tested against any other version (or indeed on any other operating system).
