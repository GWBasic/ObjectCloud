#region License

/*
 * Copyright � 2002-2006 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#endregion


#region Imports

using System;
using System.Collections.Generic;

#endregion

/// <summary>
/// Default implementation of the <see cref="IContactService"/>
/// service interface.
/// </summary>
/// <author>Bruno Baia</author>
/// <version>$Id: ContactService.cs,v 1.1 2007/05/31 18:34:54 markpollack Exp $</version>
public class ContactService : IContactService
{
    private List<string> _emails;

    /// <summary>
    /// List of emails addresses for all contacts.
    /// </summary>
    public List<string> Emails
    {
        get { return _emails; }
        set { _emails = value; }
    }

    /// <summary>
    /// Creates a new instance of the <see cref="ContactService"/> class.
    /// </summary>
    public ContactService()
    {
    }

    /// <summary>
    /// Returns an array of emails, with a maximum of <paramref name="count"/> 
    /// values, that complete the given <paramref name="prefixText"/>.
    /// </summary>
    /// <param name="prefixText">Text entered by the user.</param>
    /// <param name="count">Maximum number of possible values.</param>
    /// <returns>The array of emails for completing the text.</returns>
    public string[] GetEmails(string prefixText, int count)
    {
        List<String> emails = new List<string>();
        int i = 0;
        foreach (string email in _emails)
        {
            if (email.ToLower().StartsWith(prefixText.ToLower()))
            {
                emails.Add(email);
                if (++i == count) break;
            }
        }

        return emails.ToArray();
    }
}
