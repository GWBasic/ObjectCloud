using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using ExtremeSwank.OpenId;

public partial class OpenIDMasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void OpenID_Login(object sender, EventArgs e)
    {
    }

    protected void OpenID_ValidateSuccess(object sender, EventArgs e)
    {
    }

    public OpenIdUser OpenIdUser
    {
        get
        {
            return OpenIDControl1.UserObject;
        }
    }

}
