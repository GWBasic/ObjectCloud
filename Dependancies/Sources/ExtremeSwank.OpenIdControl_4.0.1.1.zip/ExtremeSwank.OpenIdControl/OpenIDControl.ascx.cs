using System;
using System.Collections.Generic;
using System.IO;
using System.Web;
using System.Web.Security;
using ExtremeSwank.OpenId;
using ExtremeSwank.OpenId.PlugIns.Extensions;
using ExtremeSwank.OpenId.Persistence;

public partial class OpenIDControl : System.Web.UI.UserControl
{
    /// <summary>
    /// Executed every time page is loaded. Checks for OpenID-related requests,
    /// and processes, if present.
    /// </summary>
    /// <param name="sender">Object invoking this method.</param>
    /// <param name="e">EventArgs associated with the request.</param>
    protected void Page_Load(object sender, EventArgs e)
    {
        Trace.TraceFinished += new TraceContextEventHandler(Trace_TraceFinished);
        if (!IsPostBack)
        {
            if (UserObject != null)
            {
                FormPanel.Visible = false;
                StatusPanel.Visible = true;
            }

            OpenIdClient openid = GetConsumer();
            openid.DetectAndHandleResponse();
        }
    }

    /// <summary>
    /// Create an OpenIdClient object, and set up the event listeners.
    /// </summary>
    /// <returns>An OpenIdClient object.</returns>
    protected OpenIdClient GetConsumer()
    {
        OpenIdClient openid = new OpenIdClient();
        if (AuthMode == AuthenticationMode.Stateful)
        {
            ApplicationAssociationManager associationManager = new ApplicationAssociationManager();
            SessionSessionManager sessionManager = new SessionSessionManager();
            openid.EnableStatefulMode(associationManager, sessionManager);
        }
        openid.ValidationSucceeded += new EventHandler(openid_ValidationSucceeded);
        openid.ValidationFailed += new EventHandler(openid_ValidationFailed);
        openid.ReceivedCancel += new EventHandler(openid_ReceivedCancelResponse);
        openid.ReceivedSetupNeeded += new EventHandler(openid_SetupNeeded);
        return openid;
    }

    /// <summary>
    /// Initialize SimpleRegistration plug-in, and register with OpenIdClient.
    /// </summary>
    /// <param name="openid">OpenIdClient to register against.</param>
    protected void AddPlugins(OpenIdClient openid)
    {
        SimpleRegistration sr = new SimpleRegistration(openid);
        if (!String.IsNullOrEmpty(this.RequiredFields)) { sr.RequiredFields = this.RequiredFields; }
        if (!String.IsNullOrEmpty(this.OptionalFields)) { sr.OptionalFields = this.OptionalFields; }
        if (!String.IsNullOrEmpty(this.PolicyURL)) { sr.PolicyUrl = new Uri(this.PolicyURL); }
    }

    /// <summary>
    /// An immediate request response has been received, but the user is not
    /// logged in at the OpenID Provider.  Will redirect user to OpenID Provider.
    /// </summary>
    /// <param name="sender">Object invoking this method.</param>
    /// <param name="e">Eventargs associated with the request.</param>
    protected void openid_SetupNeeded(object sender, EventArgs e)
    {
        OpenIdClient openid = (OpenIdClient)sender;
        AddPlugins(openid);
        openid.CreateRequest();
    }

    /// <summary>
    /// Handle when a user cancels the authentication request at the OpenID Provider.
    /// </summary>
    /// <param name="sender">Object invoking this method.</param>
    /// <param name="e">Eventargs associated with the request.</param>
    protected void openid_ReceivedCancelResponse(object sender, EventArgs e)
    {
        FormPanel.Visible = true;
        StatusPanel.Visible = false;
        LLabel.Text = TranslateError(ErrorCondition.RequestCanceled);
        OnRemoteCancel(e);
        OnResponseProcessed(e);
    }

    /// <summary>
    /// Handle when an authentication response has been received, and has been
    /// successfully validated.
    /// </summary>
    /// <param name="sender">Object invoking this method.</param>
    /// <param name="e">Eventargs associated with the request.</param>
    protected void openid_ValidationSucceeded(object sender, EventArgs e)
    {
        _UserObject = ((OpenIdClient)sender).RetrieveUser();
        FormPanel.Visible = false;
        StatusPanel.Visible = true;
        OnValidateSuccess(e);
        OnResponseProcessed(e);
    }

    /// <summary>
    /// Handle when an authentication response has been received, but 
    /// validation failed.
    /// </summary>
    /// <param name="sender">Object invoking this method.</param>
    /// <param name="e">Eventargs associated with the request.</param>
    protected void openid_ValidationFailed(object sender, EventArgs e)
    {
        FormPanel.Visible = true;
        StatusPanel.Visible = false;
        LLabel.Text = TranslateError(((OpenIdClient)sender).ErrorState);
        OnValidateFail(e);
        OnResponseProcessed(e);
    }

    /// <summary>
    /// Event fires upon successful validation received from 
    /// Identity Provider.
    /// </summary>
    public event EventHandler ValidateSuccess;

    /// <summary>
    /// Fires when successful validation is received from
    /// Identity Provider.
    /// </summary>
    /// <param name="e">EventArgs</param>
    protected virtual void OnValidateSuccess(EventArgs e)
    {
        if (ValidateSuccess != null)
        {
            ValidateSuccess(this, e);
        }
    }

    /// <summary>
    /// Event fires when unsuccessful validation is received frmo
    /// Identity Provider
    /// </summary>
    public event EventHandler ValidateFail;

    /// <summary>
    /// Fires when unsuccessful validation is received from
    /// Identity Provider
    /// </summary>
    /// <param name="e">EventArgs</param>
    protected virtual void OnValidateFail(EventArgs e)
    {
        if (ValidateFail != null)
        {
            ValidateFail(this, e);
        }
    }
    /// <summary>
    /// Event fires when user cancels request at Identity Provider
    /// and is redirected back to this application.
    /// </summary>
    public event EventHandler RemoteCancel;

    /// <summary>
    /// Fires when user cancels request at Identity Provider
    /// and is redirected back to this application.
    /// </summary>
    /// <param name="e"></param>
    protected virtual void OnRemoteCancel(EventArgs e)
    {
        if (RemoteCancel != null)
        {
            RemoteCancel(this, e);
        }
    }

    /// <summary>
    /// Event fires after user has submitted login form,
    /// but before performing authentication-related functions.
    /// </summary>
    public event EventHandler Login;

    /// <summary>
    /// Fires after user has submitted login form, but
    /// before performing authentication-related functions.
    /// </summary>
    /// <param name="e">EventArgs</param>
    protected virtual void OnLogin(EventArgs e)
    {
        if (Login != null)
        {
            Login(this, e);
        }
    }

    /// <summary>
    /// Event fires when a OpenID response is received and processing has completed.
    /// </summary>
    public event EventHandler ResponseProcessed;

    protected virtual void OnResponseProcessed(EventArgs e)
    {
        if (ResponseProcessed != null)
        {
            ResponseProcessed(this, e);
        }
    }

    /// <summary>
    /// Event fires after user has used the "log out" function.
    /// </summary>
    public event EventHandler Logout;

    /// <summary>
    /// Fires after user has used the "log out" function.
    /// </summary>
    /// <param name="e">EventArgs</param>
    protected virtual void OnLogout(EventArgs e)
    {
        if (Logout != null)
        {
            Logout(this, e);
        }
    }

    /// <summary>
    /// Sets the authentication mode to be used. 
    /// Supports either "stateful" or "stateless".
    /// Defaults to "stateful".
    /// </summary>
    public AuthenticationMode AuthMode
    {
        get
        {
            if (ViewState["AuthMode"] == null) { return AuthenticationMode.Stateful; }
            return (AuthenticationMode)ViewState["AuthMode"];
        }
        set
        {
            ViewState["AuthMode"] = value;
        }
    }

    /// <summary>
    /// The URL of the OpenID Provider to authenticate against.  This will result in the user being prompted for the desired
    /// OpenID by the OpenID Provider.
    /// </summary>
    /// <remarks>
    /// Setting this property to a non-blank value will result in the Identity being ignored.
    /// </remarks>
    public string OpenIDServerURL
    {
        get
        {
            if (ViewState["UseDirectedIdentity"] == null) { return null; }
            return (string)ViewState["UseDirectedIdentity"];
        }
        set
        {
            ViewState["UseDirectedIdentity"] = value;
        }
    }

    /// <summary>
    /// From Simple Registration Extension. Comma-delimited list of Simple Registration
    /// fields that the Identity Provider should require the user to provide.
    /// </summary>
    public string RequiredFields
    {
        get { return (string)ViewState["RequiredFields"]; }
        set { ViewState["RequiredFields"] = value; }
    }

    /// <summary>
    /// From Simple Registration Extension. Comma-delimited list of Simple Registration
    /// fields that the Identity Provider can optionally ask the user to provide.
    /// </summary>
    public string OptionalFields
    {
        get { return (string)ViewState["OptionalFields"]; }
        set { ViewState["OptionalFields"] = value; }
    }

    /// <summary>
    /// From Simple Registration Extension. URL of this site's privacy policy to send
    /// to the Identity Provider.
    /// </summary>
    public string PolicyURL
    {
        get { return (string)ViewState["PolicyURL"]; }
        set { ViewState["PolicyURL"] = value; }
    }

    /// <summary>
    /// Optional. Base URL of this site. Sets the scope of the authentication request. 
    /// </summary>
    public string Realm
    {
        get { return (string)ViewState["TrustRoot"]; }
        set { ViewState["TrustRoot"] = value; }
    }

    /// <summary>
    /// OpenID identitier.
    /// </summary>
    private string Identity
    {
        get { return (string)ViewState["OpenID_Identity"]; }
        set { ViewState["OpenID_Identity"] = value; }
    }

    private OpenIdUser _UserObject
    {
        get { return (OpenIdUser)Session["UserObject"]; }
        set { Session["UserObject"] = value; }
    }
    /// <summary>
    /// OpenIdUser object that represents the authenticated user and all
    /// information received from the Identity Provider.
    /// </summary>
    public OpenIdUser UserObject
    {
        get { return _UserObject; }
    }

    /// <summary>
    /// User has clicked the login button. Sets up a new OpenIdClient
    /// object and begins the authentication sequence. 
    /// Fires the OnLogin event. 
    /// </summary>
    /// <param name="sender">Object invoking this method.</param>
    /// <param name="e">EventArgs related to this request.</param>
    protected void Button_Click(object sender, EventArgs e)
    {
        OpenIdClient openid = GetConsumer();
        AddPlugins(openid);

        if (String.IsNullOrEmpty(OpenIDServerURL))
        {
            openid.Identity = openid_url.Text;
            this.Identity = openid.Identity;
        }
        else
        {
            openid.UseDirectedIdentity = true;
            openid.ProviderUrl = new Uri(OpenIDServerURL);
        }

        OnLogin(e);
        openid.CreateRequest(false, true);

        if (openid.ErrorState != ErrorCondition.NoErrors)
        {
            LLabel.Text = TranslateError(openid.ErrorState);
        }
        else
        {
            LLabel.Text = "";
        }
    }
    /// <summary>
    /// User has clicked the "log out" button. Removes all information
    /// about the user from the Session state.
    /// </summary>
    /// <param name="sender">Object invoking this method.</param>
    /// <param name="e">EventArgs associated with the request.</param>
    protected void LogOutButton_Click(object sender, EventArgs e)
    {
        OnLogout(e);
        HttpContext.Current.Session.Clear();
        FormPanel.Visible = true;
        StatusPanel.Visible = false;
    }
    /// <summary>
    /// Creates a new instance of OpenIDControl.
    /// </summary>
    public OpenIDControl()
    {
    }

    /// <summary>
    /// Translate errors received from Consumer to user-visible text.
    /// </summary>
    /// <param name="error">Value from Errors enumeration</param>
    /// <returns>A user-visible string matching the error</returns>
    public string TranslateError(ErrorCondition error)
    {
        switch (error)
        {
            case ErrorCondition.NoErrors:
                return null;
            case ErrorCondition.HttpError:
                return "Connection to OpenID Provider failed. Please try again later.";
            case ErrorCondition.NoIdSpecified:
                return "Please specify an OpenID.";
            case ErrorCondition.NoServersFound:
                return "Unable to locate OpenID Provider. Double-check your OpenID.";
            case ErrorCondition.RequestRefused:
                return "OpenID Provider refused authentication request.";
            case ErrorCondition.SessionTimeout:
                return "Session timed out. Please try again.";
            case ErrorCondition.RequestCanceled:
                return "Login request cancelled.";
            default:
                return null;
        }
    }

    /// <summary>
    /// If tracing is enabled, write a OpenID-specific log file to the current directory
    /// upon processing completion.
    /// </summary>
    /// <param name="sender">Object invoking this method.</param>
    /// <param name="e">Eventargs associated with this request.</param>
    void Trace_TraceFinished(object sender, TraceContextEventArgs e)
    {
        List<string> list = new List<string>();
        list.Add("Timestamp: " + DateTime.Now);
        foreach (TraceContextRecord tcr in e.TraceRecords)
        {
            if (tcr.Category == "openid")
            {
                list.Add(tcr.Message);
            }
        }
        list.Add("--------------------");
        string alltext = String.Join("\n", list.ToArray()) + "\n";
        File.AppendAllText(Server.MapPath("~/openid.log"), alltext);
        alltext = null;
        list = null;
    }
}
