using System;
using ExtremeSwank.OpenId;
using ExtremeSwank.OpenId.PlugIns.Extensions;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void Page_PreRender(object sender, EventArgs e)
    {
        OpenIdUser oiu = ((OpenIDMasterPage)Master).OpenIdUser;
        if (User.Identity != null)
        {
            ASPNETName.Text = User.Identity.Name;
        }

        if (oiu != null)
        {
            ActualID.Text = oiu.BaseIdentity;
            Nickname.Text = oiu.GetValue(SimpleRegistrationFields.Nickname);
            Email.Text = oiu.GetValue(SimpleRegistrationFields.Email);
            DoB.Text = oiu.GetValue(SimpleRegistrationFields.DateOfBirth);
            Gender.Text = oiu.GetValue(SimpleRegistrationFields.Gender);
            FullName.Text = oiu.GetValue(SimpleRegistrationFields.FullName);
        }
        else
        {
            PersonalPanel.Visible = false;
        }
    }
}
