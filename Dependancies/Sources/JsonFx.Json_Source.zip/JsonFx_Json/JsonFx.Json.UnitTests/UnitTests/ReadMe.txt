Any *.json file in this folder will be processed.

Download http://www.json.org/JSON_checker/test.zip and place contents into this folder.
