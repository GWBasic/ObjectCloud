/*------------------------------------------------------------------*\
	This is auto-generated code.  All changes will be overwritten.
\*------------------------------------------------------------------*/

#region 1.0.901.507

using System.Reflection;

[assembly: AssemblyVersion("1.0.901.507")]

#endregion 1.0.901.507
