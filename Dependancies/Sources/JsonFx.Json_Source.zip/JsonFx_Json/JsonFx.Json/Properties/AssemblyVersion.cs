/*------------------------------------------------------------------*\
	This is auto-generated code.  All changes will be overwritten.
\*------------------------------------------------------------------*/

#region 1.0.901.318

using System.Reflection;

[assembly: AssemblyVersion("1.0.901.318")]

#endregion 1.0.901.318
