jsio('import .client.player, .client.protocol');

exports = {
	WorldPlayer: client.player.WorldPlayer,
	WorldProtocol: client.protocol.WorldProtocol
};
