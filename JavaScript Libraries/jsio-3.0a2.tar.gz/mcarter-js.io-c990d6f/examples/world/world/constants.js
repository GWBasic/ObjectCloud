exports = {
	kBounds: {
		minX: 0, maxX: 640,
		minY: 0, maxY: 480
	},
	kGameWidth: 640,
	kGameHeight: 480,
	kPlayerSize: 25,
	kSprite: {
		up: [165, -5],
		down: [223, -5],
		left: [104, -5],
		right: [283, -38]
	}
};
